﻿namespace BDModel
{
    public class Class1
    {

    }
}