﻿namespace IServices
{
    public class Class1
    {

    }
}