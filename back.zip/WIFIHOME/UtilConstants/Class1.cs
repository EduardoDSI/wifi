﻿namespace UtilConstants
{
    public class Class1
    {

    }
}