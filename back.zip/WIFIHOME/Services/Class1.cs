﻿namespace Services
{
    public class Class1
    {

    }
}