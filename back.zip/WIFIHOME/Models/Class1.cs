﻿namespace Models
{
    public class Class1
    {

    }
}